(() => {
  const quotes = [
    { t: "The unexamined life is not worth living.", a: "Socrates" },
    { t: "I think, therefore I am.", a: "René Descartes" },
    { t: "The journey of a thousand miles begins with a single step.", a: "Lao Tzu" },
    { t: "Well done is better than well said.", a: "Benjamin Franklin" },
    { t: "Imagination is more important than knowledge.", a: "Albert Einstein" },
    { t: "The only way to do great work is to love what you do.", a: "Steve Jobs" },
    { t: "We are what we repeatedly do. Excellence, then, is not an act, but a habit.", a: "Will Durant" },
    { t: "That which does not kill us makes us stronger.", a: "Friedrich Nietzsche" },
    { t: "The best way to predict the future is to invent it.", a: "Alan Kay" },
    { t: "Talk is cheap. Show me the code.", a: "Linus Torvalds" },
    { t: "Do what you can, with what you have, where you are.", a: "Theodore Roosevelt" },
    { t: "Courage is grace under pressure.", a: "Ernest Hemingway" },
    { t: "Not all those who wander are lost.", a: "J.R.R. Tolkien" },
    { t: "It does not matter how slowly you go as long as you do not stop.", a: "Confucius" },
    { t: "Fall seven times, stand up eight.", a: "Japanese proverb" },
    { t: "No one can make you feel inferior without your consent.", a: "Eleanor Roosevelt" },
    { t: "Genius is one percent inspiration and ninety-nine percent perspiration.", a: "Thomas Edison" },
    { t: "If I have seen further, it is by standing on the shoulders of giants.", a: "Isaac Newton" },
    { t: "The only thing we have to fear is fear itself.", a: "Franklin D. Roosevelt" },
    { t: "Turn your wounds into wisdom.", a: "Oprah Winfrey" },
  ];

  const content = document.getElementById("content");
  const quoteEl = document.getElementById("quote");
  const authorEl = document.getElementById("author");
  const btn = document.getElementById("newBtn");

  // Shuffle bag: every quote appears once before any repeats,
  // and the same quote never shows twice in a row.
  let bag = [], last = -1, busy = false;
  function nextIndex() {
    if (!bag.length) {
      bag = quotes.map((_, i) => i);
      for (let i = bag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [bag[i], bag[j]] = [bag[j], bag[i]];
      }
      if (bag[bag.length - 1] === last) bag.unshift(bag.pop());
    }
    return (last = bag.pop());
  }

  function show(i) {
    quoteEl.textContent = quotes[i].t;
    authorEl.textContent = quotes[i].a;
  }

  function change() {
    if (busy) return;
    busy = true;
    content.classList.add("out");
    setTimeout(() => {
      show(nextIndex());
      content.classList.remove("out");
      content.classList.add("pre");
      void content.offsetWidth;
      content.classList.remove("pre");
      setTimeout(() => (busy = false), 300);
    }, 300);
  }

  show(nextIndex());
  btn.addEventListener("click", change);
  document.addEventListener("keydown", (e) => {
    if ((e.key === " " || e.key === "Enter") && e.target === document.body) {
      e.preventDefault();
      change();
    }
  });
})();
